<?php

define( 'REDIRECTION_VERSION', '5.3.6' );
define( 'REDIRECTION_BUILD', '16d9cc72e7ac56bb977b78fce03e6ba0' );
define( 'REDIRECTION_MIN_WP', '5.4' );
